﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

class BetterDiscordLocalInstaller
{
    static async Task Main()
    {
        string currentDir = AppDomain.CurrentDomain.BaseDirectory;

        string bdCliExePath = Path.Combine(currentDir, "bdcli", "bdcli.exe");
        if (!File.Exists(bdCliExePath))
        {
            Environment.ExitCode = 1;
            return;
        }
        if (IsBetterDiscordAlreadyActive())
        {
            return;
        }
        KillDiscordHardcore();

        bool success = await RunLocalCliAsync(bdCliExePath);

        if (success)
        {
            StartDiscord();
        }
        else
        {
            Environment.ExitCode = 1;
        }
    }
    static bool IsBetterDiscordAlreadyActive()
    {
        try
        {
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string discordPath = Path.Combine(localAppData, "Discord");

            if (!Directory.Exists(discordPath)) return false;

            var appDirs = Directory.GetDirectories(discordPath, "app-*");
            string? latestAppDir = appDirs
                .Select(dir => {
                    string folderName = Path.GetFileName(dir).Replace("app-", "");
                    bool isValid = Version.TryParse(folderName, out Version? parsedVersion);
                    return new { Path = dir, Version = parsedVersion, IsValid = isValid };
                })
                .Where(d => d.IsValid && d.Version != null)
                .OrderByDescending(d => d.Version)
                .Select(d => d.Path)
                .FirstOrDefault();

            if (string.IsNullOrEmpty(latestAppDir)) return false;

            string modulesPath = Path.Combine(latestAppDir, "modules");
            if (!Directory.Exists(modulesPath)) return false;

            var coreDirs = Directory.GetDirectories(modulesPath, "discord_desktop_core*");
            foreach (var dir in coreDirs)
            {
                string indexPath = Path.Combine(dir, "discord_desktop_core", "index.js");
                if (File.Exists(indexPath))
                {
                    string content = File.ReadAllText(indexPath);
                    if (content.Contains("betterdiscord", StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }
        }
        catch
        {
            return false;
        }

        return false;
    }

    static async Task<bool> RunLocalCliAsync(string cliPath)
    {
        try
        {
            using (Process cliProcess = new Process())
            {
                cliProcess.StartInfo = new ProcessStartInfo
                {
                    FileName = cliPath,
                    Arguments = "install --channel stable --silent",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = false,
                    RedirectStandardError = false
                };

                cliProcess.Start();
                await cliProcess.WaitForExitAsync();

                return cliProcess.ExitCode == 0;
            }
        }
        catch
        {
            return false;
        }
    }

    static void KillDiscordHardcore()
    {
        try
        {
            var startInfo = new ProcessStartInfo
            {
                FileName = "taskkill.exe",
                Arguments = "/f /im Discord.exe",
                CreateNoWindow = true,
                UseShellExecute = false
            };
            using (var p = Process.Start(startInfo))
            {
                p?.WaitForExit();
            }
            Thread.Sleep(1500);
        }
        catch { }
    }

    static void StartDiscord()
    {
        string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        string discordUpdateExe = Path.Combine(localAppData, "Discord", "Update.exe");

        if (File.Exists(discordUpdateExe))
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = discordUpdateExe,
                Arguments = "--processStart Discord.exe",
                UseShellExecute = true
            });
        }
    }
}
